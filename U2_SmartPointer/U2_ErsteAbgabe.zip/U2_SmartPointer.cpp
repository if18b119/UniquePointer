#include <iostream>
#include <memory>
#include "MyUniquePointer.h"
#include <string.h>
#include <cassert>
using namespace thebettersmartpointer;
class Entity {
private:
    int id=NULL;
public:
    Entity()
    {
    }
    Entity(int id)
    {
        this->id = id;
    }
    int GetID() noexcept { return id; }
    void SetID(int id) { this->id = id; }
};

void TestWorkingSmartPointer()
{
    MyUniquePointer<Entity> entityPointer(new Entity(1));
    MyUniquePointer<std::string> stringPointer(new std::string("Hello World"));

    assert(entityPointer->GetID(),1);
    assert(stringPointer->c_str(),"Hello World");
}

void TestSwap()
{
    MyUniquePointer<Entity> entityPointer1(new Entity(1));
    MyUniquePointer<Entity> entityPointer2(new Entity(2));

    entityPointer1.swap(entityPointer2);
    assert(entityPointer1->GetID(), 2);
    assert(entityPointer2->GetID(), 1);
}


void TestSwapWithInSelf()
{
    MyUniquePointer<Entity> entityPointer1(new Entity(1));
    entityPointer1.swap(entityPointer1);
    assert(entityPointer1->GetID(), 1);
}

void TestSwapWithNullptr()
{
    MyUniquePointer<Entity> entityPointer1(new Entity(1));
    MyUniquePointer<Entity> null_ptr;
    entityPointer1.swap(null_ptr);

    if (null_ptr && !entityPointer1)
    {
        assert(1==1);
    }
    else {
        assert(1 == 2);
    }

}

void TestBoolOperator()
{
    MyUniquePointer<Entity> entityPointer1(new Entity(1));
    MyUniquePointer<Entity> null_ptr;
    entityPointer1.swap(null_ptr);

    if (null_ptr && !entityPointer1)
    {
        assert(1 == 1);
    }
    else {
        assert(1 == 2);
    }
}

//void TestRelease()
//{
//    MyUniquePointer<Entity> entityPointer1(new Entity(1));
//    MyUniquePointer<Entity> entityPointer12(new Entity());
//    entityPointer12->SetID(entityPointer1.release());
//    assert(entityPointer12.GetID(), 1);
//}

void RunTests()
{
    std::cout << "Running Test 1 - ";
    TestWorkingSmartPointer();
    std::cout << "Passed!" << std::endl;
    std::cout << "Running Test 2 - ";
    TestSwap();
    std::cout << "Passed!" << std::endl;
    std::cout << "Running Test 3 - ";
    TestSwapWithInSelf();
    std::cout << "Passed!" << std::endl;
    std::cout << "Running Test 4 - ";
    TestSwapWithNullptr();
    std::cout << "Passed!" << std::endl;
    std::cout << "Running Test 5 - ";
    void TestBoolOperator();
    std::cout << "Passed!" << std::endl;
}

int main()
{
  
    RunTests();


    
}

