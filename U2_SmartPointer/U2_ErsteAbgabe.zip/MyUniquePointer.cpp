#include <iostream>
//unique pointer ist ein wrapper von einem pointer der sich f�r die memorie mangment geschichten k�mmert

/*
Problem beim UniquePointer sind die standard implementierung des Kompilers der rule of three:
Kopy konstruktor -> wenn der pointer ein scope verl�sst wird er gel�scht, exisitert aber eine kopie vom pointer so wird der
Destruktor beim orginalen pointer aufgerufen und bei der kopie das auf dem selben speicherplatz pointet
und das f�hrt zu einen undefined behavior

Assignment Operation -> UniquePointer1 = UniquePointer2 -> das problem hier ist das der originale Pointer der in UnqiuePointer1
vorhanden war, verloren geht.

*/
namespace thebettersmartpointer
{
	template <typename T>
	class MyUniquePointer
	{
		private:
			T* data;
		public:
			//Die vom compiler generierten rule of 3 l�schen um die probleme zu vermeiden die oben erw�hnt worden sind
			MyUniquePointer(MyUniquePointer const&) = delete;
			MyUniquePointer& operator=(MyUniquePointer const&) = delete;
			MyUniquePointer()
			{
					
			}
			//Explicit constructor -> um zu verhindern, dass der compiler falsch castet
			explicit MyUniquePointer (T* data)
			{
				this->data = data;
			}

			//destruktor
			~MyUniquePointer()
			{
				delete data;
			}

			//Operator�berladung
			T* operator->() const
			{
				return data;
			}

			T& operator*() const 
			{
				return *data;
			}

			explicit operator bool() const
			{
				return data;
			}
			//----//

			T* get() const
			{
				return data;
			}
			
			//nimmt die ownership vom gewrappten objekt weg und returned diesen und der aktuelle pointer wird null
			T* release()
			{
				if (this->data != nullptr)
				{
					T* data2 = nullptr;
					std::swap(data2, data);
					return data2;
				}
				else return;
				
			}

			void reset()
			{
				if(this->data != nullptr)
					std::swap(this->data, nullptr);
			}

			bool operator==(const MyUniquePointer& other) const
			{
				return data == other.data;
			}

			bool operator!=(const MyUniquePointer& other) const
			{
				return !(*this == other);
			}

			void swap(MyUniquePointer& data2)
			{
				if (*this != data2)
				{
					T* tmp = data2.data;
					data2.data = this->data;
					data = tmp;
				}
				
			}
	};
}

